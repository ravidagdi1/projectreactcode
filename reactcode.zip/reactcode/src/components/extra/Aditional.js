import React from "react";
import { Link } from "react-router-dom";
const Extra = () => {
  return (
    <section
    className="content-bottom clearfix"
    style={{ marginTop: "40px" }}
  >
    <div className="enter-game-question">
      <div
        className="mobile-footer-menu--title"
        style={{ paddingLeft: "20px" }}
      >
        {" "}
        Additional Links{" "}
      </div>
      <div className="accordion" id="accordionExample">
        <div className="accordion-item">
          <h2 className="accordion-header" id="headingOne">
            <button
              className="accordion-button collapsed"
              type="button"
              data-bs-toggle="collapse"
              data-bs-target="#collapseOne"
              aria-expanded="false"
              aria-controls="collapseOne"
            >
              How to play
            </button>
          </h2>
          <div
            id="collapseOne"
            className="accordion-collapse collapse"
            aria-labelledby="headingOne"
            data-bs-parent="#accordionExample"
          >
            <div className="accordion-body">
              <p>
                <strong>
                  This is the first item&#39;s accordion body.
                </strong>{" "}
                It is shown by default, until the collapse plugin adds the
                appropriate classNamees that we use to style each element.
                These classNamees control the overall appearance, as well as
                the showing and hiding via CSS transitions. You can modify
                any of this with custom CSS or overriding our default
                variables. It&#39;s also worth noting that just about any
                HTML can go within the <code>.accordion-body</code>, though
                the transition does limit overflow.
              </p>
            </div>
          </div>
        </div>
        <div className="accordion-item">
          <h2 className="accordion-header" id="headingTwo">
            <button
              className="accordion-button collapsed"
              type="button"
              data-bs-toggle="collapse"
              data-bs-target="#collapseTwo"
              aria-expanded="false"
              aria-controls="collapseTwo"
            >
              Terms &amp; Conditions
            </button>
          </h2>
          <div
            id="collapseTwo"
            className="accordion-collapse collapse"
            aria-labelledby="headingTwo"
            data-bs-parent="#accordionExample"
          >
            <div className="accordion-body">
              <p>
                <strong>
                  This is the second item&#39;s accordion body.
                </strong>
                &nbsp;It is hidden by default, until the collapse plugin
                adds the appropriate classNamees that we use to style each
                element. These classNamees control the overall appearance,
                as well as the showing and hiding via CSS transitions. You
                can modify any of this with custom CSS or overriding our
                default variables. It&#39;s also worth noting that just
                about any HTML can go within the&nbsp;
                <code>.accordion-body</code>, though the transition does
                limit overflow.
              </p>
            </div>
          </div>
        </div>
        <div className="accordion-item">
          <h2 className="accordion-header" id="headingThree">
            <button
              className="accordion-button collapsed"
              type="button"
              data-bs-toggle="collapse"
              data-bs-target="#collapseThree"
              aria-expanded="false"
              aria-controls="collapseThree"
            >
              Privacy Policy
            </button>
          </h2>
          <div
            id="collapseThree"
            className="accordion-collapse collapse"
            aria-labelledby="headingThree"
            data-bs-parent="#accordionExample"
          >
            <div className="accordion-body">
              <p>
                <strong>
                  This is the third item&#39;s accordion body.
                </strong>
                &nbsp;It is hidden by default, until the collapse plugin
                adds the appropriate classNamees that we use to style each
                element. These classNamees control the overall appearance,
                as well as the showing and hiding via CSS transitions. You
                can modify any of this with custom CSS or overriding our
                default variables. It&#39;s also worth noting that just
                about any HTML can go within the&nbsp;
                <code>.accordion-body</code>, though the transition does
                limit overflow.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div className="mobile-main-menu"> </div>
  </section>
  )};

export default Extra;