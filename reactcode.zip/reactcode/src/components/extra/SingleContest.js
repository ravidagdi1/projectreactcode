import React from "react";
import { Link } from "react-router-dom";

const SingleContest = () => {
  return (
    <>
    <div className="game-list">
      <div className="game01">
        <div className="game-img">
          <img src="admin/upload/contest/784x441.png" alt="game" />
        </div>
        <div className="game-det">
          {" "}
          <b>Testing 1.31</b>
          <p>Weekly Pick 'Em - the most correct answers wins a prize</p>
          <i id="ctimer0" style={{ display: "none" }}>
            Contest Ends <em id="demo0">09 Hrs : 54 Mins : 12 Secs</em>
          </i>
          <Link to="contest011a.html?id=60">Enter this Contest</Link>
        </div>
      </div>
    </div>
    
  </>
  );
};

export default SingleContest;