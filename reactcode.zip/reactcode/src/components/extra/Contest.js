import React from "react";

const Contest = () => {
  return (
    <>
      <main className="main"> <div className="enter-game-question">
          <div className="container-inner1 rugby1">
            <img src="admin/upload/contest/784x441.png" style={{height: '428px'}} />
            {/*<h1></h1>*/}
          </div>
        </div>
        <hr />
        <div className="enter-game-question">
          <div className="game-names">
            <div className="game-dt"> <b>Testing 1.31 </b>
              <p>Weekly Pick 'Em - the most correct answers wins a prize</p>
              <i>Closes 2023-02-27</i> {/*<a href="#">Edit Picks</a>*/} </div>
            {/*<div class="match-vs"> <em>Boston Celtics <img src="images/02.png" alt=""></em> <em>Golden State <br>
          Warriors <img src="images/01.png" alt=""></em> </div>*/}
            <div className="ques-list">
              <form action="#" method="post" id="contestForm">
                <input type="hidden" name="userid" id="userid" defaultValue={0} />
                <div className="ques-list-01"> <i>1</i>
                  <p>A or B</p>
                  <input type="hidden" name="contest_id[]" defaultValue={60} />
                  <input type="hidden" name="question_id[]" defaultValue={326} />
                  <input type="hidden" name="question[]" defaultValue="A or B" />
                  <input type="hidden" name="type[]" defaultValue={0} />
                  <label htmlFor="html"> 
                    <input type="radio" id="op1" onclick="selectRadio(0);" name="op326" required defaultValue="A" /> A								</label><br />
                  <label htmlFor="html"> 
                    <input type="radio" id="op2" onclick="selectRadio(0);" name="op326" required defaultValue="B" /> B								</label><br />
                  <input type="hidden" name="answer[]" />
                  <br />
                </div>
                <hr /> <br /><br />
                <div className="ques-list-01"> <i>2</i>
                  <p>Favorite Volor</p>
                  <input type="hidden" name="contest_id[]" defaultValue={60} />
                  <input type="hidden" name="question_id[]" defaultValue={327} />
                  <input type="hidden" name="question[]" defaultValue="Favorite Volor" />
                  <input type="hidden" name="type[]" defaultValue={1} />
                  <input type="text" onkeypress="selectRadio(0);" name="answer[]" required placeholder="Answer" style={{width: '200px'}} />
                  <br />
                </div>
                <hr /> <br /><br />
                <div style={{textAlign: 'center', paddingBottom: '20px'}}>
                  <input type="submit" name="submit" id="submit" defaultValue="Submit" style={{display: 'none'}} className="btn-primary" /><a onclick="selectRadioSubmit()" className="btn-primary">submit</a></div>
              </form>
            </div>
          </div>
        </div>
        <div className="modal fade1" id="exampleModal" tabIndex={-1} role="dialog" aria-labelledby="exampleModalLabel">
          <div className="modal-dialog" role="document">
            <div className="modal-content" style={{background: '#fff'}}>
              <div style={{padding: '25px'}}> 
                <a onclick="disFrm(1)" className="btn  header--btn ml-2 btn-primary">Login</a>
                <a onclick="disFrm(2)" className="btn  header--btn ml-2 btn-primary">New User</a>
                <form name="form1" className="form-signin" method="post">
                  <div id="loginform1" style={{display: 'block'}}>
                    <hr />
                    <div id="error_id" align="center" style={{color: '#c00000', background: 'none', lineHeight: '40px', textShadow: '2px 0px 7px rgba(255, 255, 255, 0.9)', WebkitTextShadow: '2px 0px 7px rgba(255, 255, 255, 0.9)'}} />
                    <div className="input-box">
                      <span className="error" style={{color: '#c00000', background: 'none', lineHeight: '40px', textShadow: '2px 0px 7px rgba(255, 255, 255, 0.9)', WebkitTextShadow: '2px 0px 7px rgba(255, 255, 255, 0.9)'}} />
                      {/*<label>Email</label>*/}
                      <p style={{color: 'red', marginLeft: '-10px', position: 'absolute'}}>*</p>
                      <input id="txtusername" autoComplete="off" type="email" name="txtusername" required placeholder="Email" className="form-control" /> 
                      <br />
                    </div>
                    <div className="input-box">
                      <span className="error" style={{color: '#C00'}} />
                      {/*<label>Password</label>*/}
                      <p style={{color: 'red', marginLeft: '-10px', position: 'absolute'}}>*</p>
                      <input autoComplete="off" type="password" name="txtpassword" id="txtpassword" defaultValue required placeholder="Password" className="form-control" />
                      <label><input type="checkbox" onclick="showPass()" /> Show Password</label><br /><br />
                    </div>
                    <label>
                      <input type="checkbox" defaultChecked="checked" name="remember" style={{marginBottom: '15px'}} /> Remember me
                    </label> 
                    <br />
                    {/*<input id="submit" type="submit" name="submit" value="Login" class="btn-primary btn  header--btn ml-2 btn-primary">*/}
                    <a onclick="loginFrm()" className="btn  header--btn ml-2 btn-primary">Submit</a>
                  </div>
                  <div id="loginform2" style={{display: 'none'}}>
                    <div className="form-fill  ">
                      <hr />
                      <div id="error_s" align="center" style={{color: '#c00000', background: 'none', lineHeight: '40px', textShadow: '2px 0px 7px rgba(255, 255, 255, 0.9)', WebkitTextShadow: '2px 0px 7px rgba(255, 255, 255, 0.9)'}} />
                      <div className="fullname">
                        <div className="fname">
                          <span style={{color: 'red', marginLeft: '-10px', position: 'absolute'}}>*</span>
                          <input type="text" placeholder="First Name" name="name" required className="form-control" /><br />
                        </div>
                      </div>
                      <div className="fullname">
                        <div className="fname">
                          {/*<span style="color: red;margin-left: -10px;position: absolute;">*</span>*/}
                          <input type="text" placeholder="Last Name" name="lname" className="form-control" /><br />
                        </div>
                        <div className="lname">
                          <div style={{color: 'red'}} id="emailerror" />
                          <span style={{color: 'red', marginLeft: '-10px', position: 'absolute'}}>*</span>
                          <input type="email" onchange="emailCheck()" placeholder="Email" id="email" name="email" required className="form-control" pattern="^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$" /><br />
                        </div>
                      </div>
                      <div className="fullname">
                        <div className="lname">
                          <span style={{color: 'red', marginLeft: '-10px', position: 'absolute'}}>*</span>
                          <input type="text" placeholder="Mobile No." name="phone" required className="form-control" /><br />
                        </div>
                        <div className="lname">
                          <span style={{color: 'red', marginLeft: '-10px', position: 'absolute'}}>*</span>
                          <select name="country" id="country" required className="form-control" onchange="getC();">
                            <option value>Select Country</option>
                            <option value={1}>United States</option>
                            <option value="International">International</option>
                          </select><br />
                        </div>
                        <div className="lname" id="countryother" style={{display: 'none'}}>
                          <span style={{color: 'red', marginLeft: '-10px', position: 'absolute'}}>*</span>
                          <input type="text" name="other" placeholder="Country" className="form-control" /><br />
                        </div>
                        <div className="lname" id="statediv" style={{display: 'none'}}>
                          <span style={{color: 'red', marginLeft: '-10px', position: 'absolute'}}>*</span>
                          <select name="state" id="state" className="form-control">
                            <option value="Alabama">Alabama</option>
                            <option value="Alaska">Alaska</option>
                            <option value="American Samoa">American Samoa</option>
                            <option value="Arizona">Arizona</option>
                            <option value="Arkansas">Arkansas</option>
                            <option value="California">California</option>
                            <option value="Colorado">Colorado</option>
                            <option value="Connecticut">Connecticut</option>
                            <option value="Delaware">Delaware</option>
                            <option value="District of Columbia">District of Columbia</option>
                            <option value="Federated States of Micronesia">Federated States of Micronesia</option>
                            <option value="Florida">Florida</option>
                            <option value="Georgia">Georgia</option>
                            <option value="Guam">Guam</option>
                            <option value="Hawaii">Hawaii</option>
                            <option value="Idaho">Idaho</option>
                            <option value="Illinois">Illinois</option>
                            <option value="Indiana">Indiana</option>
                            <option value="Iowa">Iowa</option>
                            <option value="Kansas">Kansas</option>
                            <option value="Kentucky">Kentucky</option>
                            <option value="Louisiana">Louisiana</option>
                            <option value="Maine">Maine</option>
                            <option value="Marshall Islands">Marshall Islands</option>
                            <option value="Maryland">Maryland</option>
                            <option value="Massachusetts">Massachusetts</option>
                            <option value="Michigan">Michigan</option>
                            <option value="Minnesota">Minnesota</option>
                            <option value="Mississippi">Mississippi</option>
                            <option value="Missouri">Missouri</option>
                            <option value="Montana">Montana</option>
                            <option value="Nebraska">Nebraska</option>
                            <option value="Nevada">Nevada</option>
                            <option value="New Hampshire">New Hampshire</option>
                            <option value="New Jersey">New Jersey</option>
                            <option value="New Mexico">New Mexico</option>
                            <option value="New York">New York</option>
                            <option value="North Carolina">North Carolina</option>
                            <option value="North Dakota">North Dakota</option>
                            <option value="Northern Mariana Islands">Northern Mariana Islands</option>
                            <option value="Ohio">Ohio</option>
                            <option value="Oklahoma">Oklahoma</option>
                            <option value="Oregon">Oregon</option>
                            <option value="Palau">Palau</option>
                            <option value="Pennsylvania">Pennsylvania</option>
                            <option value="Puerto Rico">Puerto Rico</option>
                            <option value="Rhode Island">Rhode Island</option>
                            <option value="South Carolina">South Carolina</option>
                            <option value="South Dakota">South Dakota</option>
                            <option value="Tennessee">Tennessee</option>
                            <option value="Texas">Texas</option>
                            <option value="Utah">Utah</option>
                            <option value="Vermont">Vermont</option>
                            <option value="Virgin Islands">Virgin Islands</option>
                            <option value="Virginia">Virginia</option>
                            <option value="Washington">Washington</option>
                            <option value="West Virginia">West Virginia</option>
                            <option value="Wisconsin">Wisconsin</option>
                            <option value="Wyoming">Wyoming</option>
                          </select><br />
                        </div>
                      </div>
                      <div className="fullname">
                        <div className="fname">
                          <span style={{color: 'red', marginLeft: '-10px', position: 'absolute'}}>*</span>
                          <input type="password" placeholder="Password" name="password" id="password" required className="form-control" />
                          <label><input type="checkbox" onclick="showPass1()" /> Show Password</label>
                          <br /><br />
                        </div>
                      </div>
                      <p style={{textAlign: 'center'}}><span style={{color: 'red', marginLeft: '-10px', position: 'absolute'}}>*</span>
                        <input type="checkbox" name="tp" defaultChecked required style={{marginBottom: '15px'}} /> By creating an account you agree to our <a href="#" style={{color: 'dodgerblue'}}>Terms &amp; Privacy</a>.</p>  
                      <div className="clearfix" style={{textAlign: 'center'}}>       
                        <a onclick="signupFrm()" className="btn  header--btn ml-2 btn-primary">Sign Up</a>
                      </div>
                    </div>
                  </div>
                </form>
                {/*<div class="header--item"><a href="login.php" class="btn header--btn btn-outline">Login</a> 
			<a href="signup.php" class="btn  header--btn ml-2 btn-primary">New User</a></div>*/}
                <button type="button" className="btn btn-default" data-dismiss="modal" style={{color: '#FFF'}}>Close</button>
              </div>
            </div>
          </div>
        </div>
        <section className="content-bottom clearfix" style={{marginTop: '40px'}}>
          <div className="enter-game-question">
            <div className="mobile-footer-menu--title" style={{paddingLeft: '20px'}}> Additional Links </div>
            <div className="accordion" id="accordionExample">
              <div className="accordion-item">
                <h2 className="accordion-header" id="headingOne">
                  <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                    Prize for Testing 1.31    </button>
                </h2>
                <div id="collapseOne" className="accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                  <div className="accordion-body">
                    <table className="align-middle mb-0 table table-borderless table-striped table-hover dataTable no-footer">
                      <tbody><tr>
                          <th className="text-center sorting_1">Image</th>
                          <th className="text-center sorting_1">Prize</th>
                          <th className="text-center sorting_1">Prize Code</th>
                          <th className="text-center sorting_1">URL</th>
                          <th className="text-center sorting_1">Rank</th>
                        </tr>
                        <tr>
                          <td className="text-center sorting_1"><img src="admin/upload/contest/784x441.png" style={{height: '50px'}} /></td>
                          <td className="text-center sorting_1">50% playmaker order</td>
                          <td className="text-center sorting_1">prize1</td>
                          <td className="text-center sorting_1" />
                          <td className="text-center sorting_1">1</td>
                        </tr>
                      </tbody></table>
                  </div>
                </div>
              </div>
              <div className="accordion-item">
                <h2 className="accordion-header" id="headingTwo">
                  <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                    Terms &amp; Conditions
                  </button>
                </h2>
                <div id="collapseTwo" className="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                  <div className="accordion-body">
                    <p><strong>This is the second item's accordion body.</strong>&nbsp;It is hidden by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the&nbsp;<code>.accordion-body</code>, though the transition does limit overflow.</p>
                  </div>
                </div>
              </div>
              <div className="accordion-item">
                <h2 className="accordion-header" id="headingThree">
                  <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                    Privacy Policy
                  </button>
                </h2>
                <div id="collapseThree" className="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                  <div className="accordion-body">
                    <p><strong>This is the third item's accordion body.</strong>&nbsp;It is hidden by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the&nbsp;<code>.accordion-body</code>, though the transition does limit overflow.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="mobile-main-menu"> </div>
        </section>
      </main>
    </>
  );
};

export default Contest;
