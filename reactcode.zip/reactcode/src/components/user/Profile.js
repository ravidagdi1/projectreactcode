import React, { useContext, useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import Cont from "../extra/SingleContest";
import Extra from "../extra/Aditional";

const Mid = () => {
  let navigate=useNavigate()
  useEffect(()=>{
    let token=window.localStorage.getItem('token')
    let headers = {
      "Authorization": "Bearer" + token
  }
    fetch('/api/v1/viewUserDetail',{
      headers:headers
    }).then((result)=>{return result.json()}).then((data)=>{
      //console.log(data)
      if(data.status===200){
        
      }else{
        navigate('/login')
      }
    })
  },[])

  return (
    <>
    
    </>
  );
};

export default Mid;