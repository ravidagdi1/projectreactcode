import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { toast } from "react-toastify";
// import SpinnerLoader from "../common/Slider";

const Signup = () => {
  const [firstName, setFirstname] = useState('');
  const [lastName, setLastname] = useState('');
  const [email, setEmail] = useState('');
  const [mobileNumber, setMobileNumber] = useState('');
  const [country, setCountry] = useState('');
  const[other,setOther]=useState('')
  const[state,setState]=useState(1)
  const[password,setPassword]=useState('')
  const[ipAddress,setIpaddress]=useState('')
  const [formErrors, setFormErrors] = useState('');
  const [loading, setLoading] = useState(false);
  const handleSubmit = async (e) => {
    e.preventDefault(e);
    const inputs= {firstName,lastName,email,mobileNumber,country,other,password,state,ipAddress};
    console.log(inputs)
    await fetch('/api/v1/signupUser',{
      method:'POST',
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify(inputs)
    }).then((result)=>{return result.json()}).then((data)=>{
      console.log(data)
      if(data.status===200){
        setFormErrors(data.message)
      }else{
        setFormErrors(data.message)
      }
      

    })
  }
    /*const { firstName, lastName, email, phone, password } = inputs;
    console.log(firstName)
    const result = validate(inputs);
    if (Object.keys(result).length) {
      setFormErrors(result);
    } else {
      setFormErrors({});
      const formData = new FormData();
      formData.append("firstName", inputs.firstName);
      formData.append("lastName", inputs.lastName);
      formData.append("email", inputs.email);
      formData.append("mobile", inputs.phone);
      formData.append("password", inputs.password);

      try {
        // setLoading(true);
        const resp = await fetch("/api/v1/signupUser", {
          method: "POST",
          headers: {"Content-Type": "appliaction/json"},
          body: JSON.stringify({
            firstName,
            lastName,
            email,
            phone,
            password,
          }),
        });

        const response = await resp.json();
        console.log("formData", response);

        if (response.error) {
          toast.error(response.message);
          // setLoading(false);
        } else if (response.error === false) {
          toast.success(response.message);
          // setLoading(false);
          window.location.href("/login");
        } else {
          toast.warning(response);
          // setLoading(false);
        }

        // setLoading(true);
      } catch (error) {
        // eslint-disable-next-line no-console
        console.log(error);
      }
    }
  };

  const validate = (values) => {
    setFormErrors({});
    const errors = {};
    const emailRegex =
      /^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;

    const passReg =
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*.,#?&])[A-Za-z\d@$!%*.,#?&]{8,50}$/;

    if (!values.firstname) {
      errors.firstname = "First name is required!";
    }

    if (!values.lastname) {
      errors.lastname = "Last name is required!";
    }

    if (!values.email) {
      errors.email = "Email field is required!";
    } else if (!emailRegex.test(values.email)) {
      errors.email = "Enter valid email address!";
    }
    if (!parseInt(values.mobile)) {
      errors.mobile = "Enter mobile number!";
    } else if (parseInt(values.mobile.length) < 9) {
      errors.mobile = "The mobile must be between 9 and 16 digits";
    } else if (parseInt(values.mobile.length) > 16) {
      errors.mobile = "The mobile not more than 16 digits";
    }

    if (!values.password) {
      errors.password = "Password is required!";
    } else if (!passReg.test(values.password)) {
      errors.password =
        "Password must be minimum 8 character should have at least one lower case, one upper case, one numeric and one special character";
    }
    return errors;
  };*/

  return (
    <>
      {/* <SpinnerLoader loading={loading} /> */}
      
      <main className="main">
        <div
          className="enter-game-question"
          style={{
            backgroundImage: `url("admin/upload/banner.jpg")`,
            height: "280px",
          }}
        >
          <div className="container-inner1 rugby1">
            <h1></h1>
          </div>
        </div>
        <hr />
        <div className="enter-game-question">
          <div className="container-inner1 login-form ">
            <div className="signing  align-item-center">
              <div className="sign">
                <h4 style={{ textAlign: "center" }}> SIGN UP</h4>
                <p style={{ textAlign: "center" }}>
                  Please fill in this form to create an account.
                </p>
              </div>
            </div>
            <h4 className="text-danger">{formErrors}</h4>
            
            <form onSubmit={(e)=>{handleSubmit(e)}}>
              <div className="form-fill  ">
                <hr />
                <div className="fullname">
                  <div className="fname">
                    <br />
                    <span
                      style={{
                        color: "red",
                        marginLeft: "-10px",
                        position: "absolute",
                      }}
                    >
                      *
                    </span>
                    <input
                      type="text"
                      placeholder="First Name"
                      name="firstName"
                      className="form-control"
                      value={firstName}
                      onChange={(e)=>{setFirstname(e.target.value)}}
                    />
                  </div>
                </div>
                <div className="fullname">
                  <div className="fname">
                    <br />
                    <span
                      style={{
                        color: "red",
                        marginLeft: "-10px",
                        position: "absolute",
                      }}
                    >
                      *
                    </span>
                    <input
                      type="text"
                      placeholder="Last Name"
                      name="lastName"
                      className="form-control"
                      value={lastName}
                      onChange={(e)=>{setLastname(e.target.value)}}
                    />
                    <span className="text-danger">{formErrors.lasttName}</span>
                    <br />
                  </div>
                  <div className="lname">
                    <div style={{ color: "red" }} id="emailerror"></div>
                    <br />
                    <span
                      style={{
                        color: "red",
                        marginLeft: "-10px",
                        position: "absolute",
                      }}
                    >
                      *
                    </span>
                    <input
                      className="form-control"
                      type="email"
                      placeholder="Email"
                      id="email"
                      name="email"
                      value={email}
                      onChange={(e)=>{setEmail(e.target.value)}}
                      required
                    />
                    <br />
                  </div>
                </div>
                <div className="fullname">
                  <div className="lname">
                    <br />
                    <span
                      style={{
                        color: "red",
                        marginLeft: "-10px",
                        position: "absolute",
                      }}
                    >
                      *
                    </span>
                    <input
                      type="text"
                      placeholder="Mobile No."
                      name="phone"
                      required
                      className="form-control"
                      value={mobileNumber}
                      onChange={(e)=>{setMobileNumber(e.target.value)}}
                    />
                    <br />
                    
                  </div>
                  <div className="lname">
                    <br />
                    <span
                      
                      style={{
                        color: "red",
                        marginLeft: "-10px",
                        position: "absolute",
                      }}
                    >
                      *
                    </span>
                    <select
                      name="country"
                      id="country"
                      required
                      className="form-control"
                      value={country}
                      onChange={(e)=>{setCountry(e.target.value)}}
                    >
                      <option value="">Select Country</option>
                      <option value="US">United States</option>
                      <option value="International">International</option>
                    </select>
                    <br />
                  </div>
                  <div
                    className="lname"
                    id="countryother"
                    style={{ display: "none" }}
                  >
                    <br />
                    <span
                      style={{
                        color: "red",
                        marginLeft: "-10px",
                        position: "absolute",
                      }}
                    >
                      *
                    </span>
                    <input
                      type="text"
                      name="other"
                      placeholder="Country"
                      className="form-control"
                      value={other}
                      onChange={(e)=>{setOther(e.target.value)}}
                    />
                    <br />
                  </div>
                  <div
                    className="lname"
                    id="statediv"
                    style={{ display: "none" }}
                  >
                    <br />
                    <span
                      style={{
                        color: "red",
                        marginLeft: "-10px",
                        position: "absolute",
                      }}
                    >
                      *
                    </span>
                    <select name="state" className="form-control"
                    value={state}
                    onChange={(e)=>{setState(e.target.value)}}
                    >
                      <option value="Alabama">Alabama</option>
                      <option value="Alaska">Alaska</option>
                      <option value="American Samoa">American Samoa</option>
                      <option value="Arizona">Arizona</option>
                      <option value="Arkansas">Arkansas</option>
                      <option value="California">California</option>
                      <option value="Colorado">Colorado</option>
                      <option value="Connecticut">Connecticut</option>
                      <option value="Delaware">Delaware</option>
                      <option value="District of Columbia">
                        District of Columbia
                      </option>
                      <option value="Federated States of Micronesia">
                        Federated States of Micronesia
                      </option>
                      <option value="Florida">Florida</option>
                      <option value="Georgia">Georgia</option>
                      <option value="Guam">Guam</option>
                      <option value="Hawaii">Hawaii</option>
                      <option value="Idaho">Idaho</option>
                      <option value="Illinois">Illinois</option>
                      <option value="Indiana">Indiana</option>
                      <option value="Iowa">Iowa</option>
                      <option value="Kansas">Kansas</option>
                      <option value="Kentucky">Kentucky</option>
                      <option value="Louisiana">Louisiana</option>
                      <option value="Maine">Maine</option>
                      <option value="Marshall Islands">Marshall Islands</option>
                      <option value="Maryland">Maryland</option>
                      <option value="Massachusetts">Massachusetts</option>
                      <option value="Michigan">Michigan</option>
                      <option value="Minnesota">Minnesota</option>
                      <option value="Mississippi">Mississippi</option>
                      <option value="Missouri">Missouri</option>
                      <option value="Montana">Montana</option>
                      <option value="Nebraska">Nebraska</option>
                      <option value="Nevada">Nevada</option>
                      <option value="New Hampshire">New Hampshire</option>
                      <option value="New Jersey">New Jersey</option>
                      <option value="New Mexico">New Mexico</option>
                      <option value="New York">New York</option>
                      <option value="North Carolina">North Carolina</option>
                      <option value="North Dakota">North Dakota</option>
                      <option value="Northern Mariana Islands">
                        Northern Mariana Islands
                      </option>
                      <option value="Ohio">Ohio</option>
                      <option value="Oklahoma">Oklahoma</option>
                      <option value="Oregon">Oregon</option>
                      <option value="Palau">Palau</option>
                      <option value="Pennsylvania">Pennsylvania</option>
                      <option value="Puerto Rico">Puerto Rico</option>
                      <option value="Rhode Island">Rhode Island</option>
                      <option value="South Carolina">South Carolina</option>
                      <option value="South Dakota">South Dakota</option>
                      <option value="Tennessee">Tennessee</option>
                      <option value="Texas">Texas</option>
                      <option value="Utah">Utah</option>
                      <option value="Vermont">Vermont</option>
                      <option value="Virgin Islands">Virgin Islands</option>
                      <option value="Virginia">Virginia</option>
                      <option value="Washington">Washington</option>
                      <option value="West Virginia">West Virginia</option>
                      <option value="Wisconsin">Wisconsin</option>
                      <option value="Wyoming">Wyoming</option>
                    </select>
                    <br />
                  </div>
                </div>
                <div className="fullname">
                  <div className="fname">
                    <br />
                    <span
                      style={{
                        color: "red",
                        marginLeft: "-10px",
                        position: "absolute",
                      }}
                    >
                      *
                    </span>
                    <input
                      type="password"
                      placeholder="Password"
                      name="password"
                      id="password"
                      required
                      className="form-control"
                      value={password}
                      onChange={(e)=>{setPassword(e.target.value)}}
                    />
                    <label>
                      <input type="checkbox" /> Show Password
                    </label>
                    <br />
                  </div>
                </div>
                <label>
                  <input
                    type="checkbox"
                    name="remember"
                    style={{ marginBottom: "15px" }}
                  />
                  Remember me
                </label>
                <p style={{ textAlign: "center" }}>
                  <span
                    style={{
                      color: "red",
                      marginLeft: "-10px",
                      position: "absolute",
                    }}
                  >
                    *
                  </span>
                  <input
                    type="checkbox"
                    name="tp"
                    required
                    style={{ marginBottom: "15px" }}
                  />{" "}
                  By creating an account you agree to our{" "}
                  <Link to="#" style={{ color: "dodgerblue" }}>
                    Terms &amp; Privacy
                  </Link>
                  .
                </p>
                <div className="clearfix" style={{ textAlign: "center" }}>
                  <button
                    type="submit"
                    className="btn-primary"
                    name="submit"
                    style={{ textAlign: "center" }}
                  >
                    Sign Up
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </main>
    </>
  );
};

export default Signup;
