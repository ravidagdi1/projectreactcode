import React, { createContext, useContext, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Contextapi } from "../../Contextapi";

const Login = () => {
  const{setData,setToken}=useContext(Contextapi)
  const navigate=useNavigate()
  const[email,setemail]=useState('')
  const[password,setPassword]=useState('')
  const[message,setMessage]=useState('')
  function handleform(e){
    e.preventDefault()
    const logindata={email,password}
    try{
    fetch('/api/v1/appLogin',{
      method:'POST',
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify(logindata)
    }).then((result)=>{return result.json()}).then((data)=>{
      if(data.status===200){
      window.localStorage.setItem('token',data.resp)
      window.localStorage.setItem('data',JSON.stringify(data.data[0]))
      setData(JSON.parse(window.localStorage.getItem('data')))
      setToken(window.localStorage.getItem('token'))
      navigate('/profile')
      }else{
        setMessage(data.message)
      }
    })
  }catch(error){
    console.log(error)
  }
  }
  return (
    <>
      <main className="main">
        <div
          className="enter-game-question"
          style={{
            backgroundImage: `url('images/1672214092banner.jpg')`,
            height: "280px",
          }}
        >
          <div className="container-inner1 rugby1">
            
          </div>
        </div>
        <div className="enter-game-question">
          <div className="container-inner flip" style={{ textAlign: "center" }}>
            <h2>Login</h2>
            <h4 className="text-start text-danger">{message}</h4>
            <form onSubmit={(e)=>{handleform(e)}}
            >
              <div className="input-box">
                <span
                  className="error"
                  style={{
                    color: "#c00000",
                    background: "none",
                    lineHeight: "40px",
                    textShadow: "2px 0px 7px rgba(255, 255, 255, 0.9)",
                  }}
                ></span>
                <label>Email</label>
                <p
                  style={{
                    color: "red",
                    marginLeft: "-10px",
                    position: "absolute",
                  }}
                >
                  *
                </p>
                <input
                  id="txtusername"
                  type="email"
                  placeholder="Email"
                  className="form-control"
                  value={email}
                  onChange={(e)=>{setemail(e.target.value)}}
                />
                <br />
              </div>
              <div className="input-box">
                <span className="error" style={{ color: "#C00" }}></span>
                <label>Password</label>
                <p
                  style={{
                    color: "red",
                    marginLeft: "-10px",
                    position: "absolute",
                  }}
                >
                  *
                </p>
                <input
                  type="password"
                  id="txtpassword"
                  value={password}
                  onChange={(e)=>{setPassword(e.target.value)}}
                  placeholder="Password"
                  className="form-control"
                />
              </div>
              <label>
                <input type="checkbox"/>
                Show Password
              </label>
              <label>
                <input
                  type="checkbox"
                  name="remember"
                  style={{ marginBottom: "15px" }}
                />{" "}
                Remember me
              </label>
              <br />
              <input
                id="submit"
                type="submit"
                name="submit"
                value="Login"
                className="btn-primary btn  header--btn ml-2 btn-primary"
              />
              <Link to="/signup" className="btn  header--btn ml-2 btn-primary">
                New User
              </Link>
            </form>
            <p>
              <Link to="/forgot">Forgot Password?</Link>
            </p>
          </div>
        </div>

        <div id="logged-in"></div>
      </main>
    </>
  );
};

export default Login;
