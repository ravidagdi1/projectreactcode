import React from "react";

const Forgot = () => {
  return (
    <>
      <main className="main">
        <div
          className="enter-game-question background-banner"
          style={{
            backgroundImage: `url('images/banner.jpg')`,
            height: "280px",
          }}
        >
          <div className="container-inner1 rugby1">
            <h1>Forgot Password</h1>
          </div>
        </div>
        <div className="enter-game-question">
          <div className="container-inner flip" style={{ textAlign: "center" }}>
            <h2>Forgot Password</h2>
            <form
              name="form1"
              className="form-signin"
              action="https://playg.softdevtest.in/forgot.php"
              method="post"
            >
              <div className="input-box">
                <span
                  className="error"
                  style={{
                    color: "#c00000",
                    background: "none",
                    lineHeight: "40px",
                    textShadow: "2px 0px 7px rgba(255, 255, 255, 0.9)",
                  }}
                ></span>
                <label>Email</label>
                <input
                  id="txtusername"
                  autocomplete="off"
                  type="email"
                  name="txtusername"
                  required
                  placeholder="Email"
                  style={{ width: "250px" }}
                />
              </div>
              <br />
              <input id="submit" type="submit" name="submit" value="Submit" />
            </form>
          </div>
        </div>
        <div id="logged-in"></div>
      </main>
    </>
  );
};

export default Forgot;
