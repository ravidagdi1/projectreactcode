import React from "react";

const About = () => {
  return (
    <div>
      <main class="main">
        {" "}
        <div
          class="enter-game-question"
          style={{
            backgroundImage: `url("admin/upload/banner.jpg")`,
            height: "280px",
          }}
        >
          <div class="container-inner1 rugby1">
            <h1></h1>
          </div>
        </div>
        <hr />
        <div class="enter-game-question">
          <div class="container-inner1 login-form ">
            <div class="signing  align-item-center">
              <div class="sign abt">
                <h2>About Us</h2>
                <p style={{ textAlign: "center" }}>
                  <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                    Suspendisse interdum eleifend augue, quis rhoncus purus
                    fermentum. In hendrerit risus arcu, in eleifend metus
                    dapibus varius. Nulla dolor sapien, laoreet vel tincidunt
                    non, egestas non justo. Phasellus et mattis lectus, et
                    gravida urna.
                  </p>

                  <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                    Suspendisse interdum eleifend augue, quis rhoncus purus
                    fermentum. In hendrerit risus arcu, in eleifend metus
                    dapibus varius. Nulla dolor sapien, laoreet vel tincidunt
                    non, egestas non justo. Phasellus et mattis lectus, et
                    gravida urna.
                  </p>

                  <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                    Suspendisse interdum eleifend augue, quis rhoncus purus
                    fermentum. In hendrerit risus arcu, in eleifend metus
                    dapibus varius. Nulla dolor sapien, laoreet vel tincidunt
                    non, egestas non justo. Phasellus et mattis lectus, et
                    gravida urna.
                  </p>

                  <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                    Suspendisse interdum eleifend augue, quis rhoncus purus
                    fermentum. In hendrerit risus arcu, in eleifend metus
                    dapibus varius. Nulla dolor sapien, laoreet vel tincidunt
                    non, egestas non justo. Phasellus et mattis lectus, et
                    gravida urna.
                  </p>

                  <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                    Suspendisse interdum eleifend augue, quis rhoncus purus
                    fermentum. In hendrerit risus arcu, in eleifend metus
                    dapibus varius. Nulla dolor sapien, laoreet vel tincidunt
                    non, egestas non justo. Phasellus et mattis lectus, et
                    gravida urna.
                  </p>
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default About;
