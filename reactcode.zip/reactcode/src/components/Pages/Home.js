import React from "react";
import { Link } from "react-router-dom";
import Cont from "../extra/SingleContest";
import Extra from "../extra/Aditional";
const Mid = () => {
  return (
    <main className="main">
      <Cont/>
      <Extra/>
    </main>
  );
};

export default Mid;
