import React from "react";
import { Link } from "react-router-dom";

const Contact = () => {
  return (
    <>
    <>
  <div
    className="enter-game-question"
    style={{ backgroundImage: 'url("admin/upload/banner.jpg")', height: 280 }}
  >
    <div className="container-inner1 rugby1">
      <h1 />
    </div>
  </div>
  <hr />
  <div className="enter-game-question">
    <div className="container-inner1 login-form ">
      <div className="signing  align-item-center">
        <div className="sign">
          <h2 style={{ textAlign: "center" }}> Contact Us</h2>
          <p style={{ textAlign: "center" }}>
            Please fill in this form to create an Enquiry.
          </p>
        </div>
      </div>
      <form
        id="frmEditPage"
        action="sendMail.php"
        method="post"
        encType="multipart/form-data"
      >
        <div className="form-fill  ">
          <hr />
          <div className="fullname">
            <div className="fname">
              <br />
              <input
                type="text"
                placeholder="Name"
                name="name"
                required=""
                className="form-control"
              />
              <br />
            </div>
            <div className="lname">
              <br />
              <input
                type="email"
                placeholder="Email"
                name="email"
                required=""
                className="form-control"
                pattern="^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$"
              />
              <br />
            </div>
          </div>
          <div className="fullname ">
            <div className="lname">
              <br />
              <input
                type="text"
                placeholder="Mobile No."
                name="phone"
                required=""
                className="form-control"
              />
              <br />
            </div>
            <div className="lname">
              <br />
              <input
                type="text"
                placeholder="Message"
                name="message"
                className="form-control"
              />
              <br />
            </div>
          </div>
          <div className="clearfix" style={{ textAlign: "center" }}>
            <button
              type="submit"
              className="btn-primary"
              name="submit"
              style={{ textAlign: "center" }}
            >
              Submit
            </button>
          </div>
        </div>
      </form>
    </div>
  </div>
</>

    </>
  )};

export default Contact