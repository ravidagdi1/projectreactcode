import React, { useContext } from "react";
import { Link, Navigate, json, useNavigate } from "react-router-dom";
import { Contextapi } from "../../Contextapi";

const Header = () => {
  const navigate=useNavigate()
  const{data,token,setToken,setData}=useContext(Contextapi)
  
  function handlelogout(e){
    window.localStorage.removeItem('data')
    setData(window.localStorage.getItem('data'))
    window.localStorage.removeItem('token')
    setToken(localStorage.getItem('token'))
    navigate('/login')
  }
  return (
    <>
      <header className="header">
        <div className="header-inner container">
          <div className="header--logo-wrapper ml-4">
            <Link to="/" className="header--logo">
              <img src="images/1671699238logo.png" alt="Logo" />
            </Link>
          </div>
          <div className="header--item">
            {!data?
            <>
            <Link to="/login" className="btn header--btn btn-outline">
              Login
            </Link>
            <Link to="/signup" className="btn  header--btn ml-2 btn-primary">
              Join Now
            </Link>
            </>
            
            :
            <>
            <button className="btn header--btn btn-outline">{`Welcome ${data.name}`}</button>
            <button className="btn  header--btn ml-2 ms-2 btn-primary" onClick={(e)=>{handlelogout(e)}}>Logout</button>
            </>
}
          </div>
        </div>
      </header>
    </>
  );
};

export default Header;
