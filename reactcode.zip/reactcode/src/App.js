import React, { useContext, useEffect, useState } from "react";
import { Routes, Route } from "react-router-dom";
import "./App.css";
import Home from "./components/Pages/Home";
import Footer from "./components/common/Footer";
import Header from "./components/common/Header";
import About from "./components/Pages/About";
import Faqs from "./components/Pages/Faqs";
import Signup from "./components/Auth/Signup";
import Login from "./components/Auth/Login";
import Forgot from "./components/Auth/Forgot";
import Contact from './components/Pages/Contact'
import Contest from "./components/extra/Contest";
import Profile from "./components/user/Profile";
import { Contextapi } from './Contextapi'

function App() {
  const[data,setData]=useState(JSON.parse(window.localStorage.getItem('data')))
  const[token,setToken]=useState(window.localStorage.getItem('token'))
  return (
    <>
    <Contextapi.Provider
     value={{data,token,setToken,setData}}>
      <Header />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/faqs" element={<Faqs />} />
        <Route path="/contest" element={<Contest />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/login" element={<Login />} />
        <Route path="/forgot" element={<Forgot />} />
        <Route path="/profile" element={<Profile/>} />

      </Routes>
      <Footer />
      </Contextapi.Provider>
    </>
  );
}

export default App;
